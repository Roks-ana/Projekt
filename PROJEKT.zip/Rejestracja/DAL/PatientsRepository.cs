﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    class PatientsRepository
    {
        private static string SELECT_PESEL = "SELECT pesel FROM `pacjenci`";

        public static List<Patient> GetPeselPatients()
        {
            List<Patient> patients = new List<Patient>();
            using (var conn = DBConnection.Instance.Connection)
            {
                conn.Open();
                using (MySqlCommand command = new MySqlCommand(SELECT_PESEL, conn))
                {
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        patients.Add(new Patient(reader));
                    }

                }



            }


            return patients;
        }
    }
}
