﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace Rejestracja.DAL
{
    class DoctorsRepository
    {
        private static string SELECT_ALL = "SELECT * FROM `lekarze`";

        public static List<Doctor> GetAllDoctors()
        {
            List<Doctor> doctors = new List<Doctor>();
            try
            {
                using (var conn = DBConnection.Instance.Connection)
                {
                    conn.Open();
                    using (MySqlCommand command = new MySqlCommand(SELECT_ALL, conn))
                    {
                        MySqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            doctors.Add(new Doctor(reader));
                        }

                    }



                }
            }
            catch (Exception exp)
            {
                throw exp;
            }


            return doctors;
        }
    }
}
