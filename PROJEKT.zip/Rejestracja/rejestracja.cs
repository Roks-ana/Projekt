﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rejestracja
{
    public partial class rejestracja : UserControl
    {
        public event Action<DAL.Doctor> SelectedDoctorChanged;

        public rejestracja()
        {
            InitializeComponent();
        }

        public DAL.Doctor[] ListLekarzy
        {
            set
            {
                Lista_lekarzy.Items.Clear();
                Lista_lekarzy.Items.AddRange(value);
            }
        }

        //public DAL.Patient[] ListPacjenci 
        //{
        //    set
        //    {
        //        PESEL.Items.Clear();
        //        PESEL.Items.AddRange(value);
        //    }
        //}
        public DAL.Visit[] ListWizyty
        {
            set
            {

                PESEL.Items.Clear();
                PESEL.Items.AddRange(value);
            }
        }
        //public DAL.Pesel[] ListPesele
        //{
        //    set
        //    {
        //        PESEL.Items.Clear();
        //        PESEL.Items.AddRange(value);
        //    }
        //}

        private void rejestracja_Load(object sender, EventArgs e)
        {

        }

        private void Lista_lekarzy_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Lista_lekarzy.SelectedItem != null)
            {
                DAL.Doctor a = Lista_lekarzy.Items[Lista_lekarzy.SelectedIndex] as DAL.Doctor;
                Lekarz.Text = a.FirstName + " " + a.LastName;
                if (SelectedDoctorChanged != null)
                    SelectedDoctorChanged((DAL.Doctor)Lista_lekarzy.SelectedItem);
                // Okno2.textBox1.Text = a.FirstName + " " + a.LastName;

            }


        }

        private void Lekarz_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Usun_wizyte_Click(object sender, EventArgs e)
        {

        }

        private void Dodaj_wizyte_Click(object sender, EventArgs e)
        {
            Okno2 okno2 = new Okno2((DAL.Doctor)Lista_lekarzy.SelectedItem);


            okno2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Okno3_cs okno3 = new Okno3_cs();
            okno3.Show();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void PESEL_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (PESEL.SelectedItem != null)
            {
                DAL.Visit w = PESEL.Items[PESEL.SelectedIndex] as DAL.Visit;
                data.Text = Convert.ToString(w.Data);
            }
        }

    }
}