﻿namespace Rejestracja
{
    partial class rejestracja
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Lista_lekarzy = new System.Windows.Forms.ListBox();
            this.PESEL = new System.Windows.Forms.ListBox();
            this.Usun_wizyte = new System.Windows.Forms.Button();
            this.Odswiez = new System.Windows.Forms.Button();
            this.Dodaj_wizyte = new System.Windows.Forms.Button();
            this.Lekarz = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.data = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(20, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Lista lekarzy";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(285, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Data";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(434, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Lekarz";
            // 
            // Lista_lekarzy
            // 
            this.Lista_lekarzy.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Lista_lekarzy.FormattingEnabled = true;
            this.Lista_lekarzy.ItemHeight = 18;
            this.Lista_lekarzy.Location = new System.Drawing.Point(24, 55);
            this.Lista_lekarzy.Name = "Lista_lekarzy";
            this.Lista_lekarzy.Size = new System.Drawing.Size(218, 238);
            this.Lista_lekarzy.TabIndex = 3;
            this.Lista_lekarzy.SelectedIndexChanged += new System.EventHandler(this.Lista_lekarzy_SelectedIndexChanged);
            // 
            // PESEL
            // 
            this.PESEL.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PESEL.FormattingEnabled = true;
            this.PESEL.ItemHeight = 18;
            this.PESEL.Location = new System.Drawing.Point(289, 109);
            this.PESEL.Name = "PESEL";
            this.PESEL.Size = new System.Drawing.Size(313, 184);
            this.PESEL.TabIndex = 5;
            this.PESEL.SelectedIndexChanged += new System.EventHandler(this.PESEL_SelectedIndexChanged);
            // 
            // Usun_wizyte
            // 
            this.Usun_wizyte.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Usun_wizyte.Location = new System.Drawing.Point(289, 318);
            this.Usun_wizyte.Name = "Usun_wizyte";
            this.Usun_wizyte.Size = new System.Drawing.Size(116, 37);
            this.Usun_wizyte.TabIndex = 6;
            this.Usun_wizyte.Text = "Usuń wizytę";
            this.Usun_wizyte.UseVisualStyleBackColor = true;
            this.Usun_wizyte.Click += new System.EventHandler(this.Usun_wizyte_Click);
            // 
            // Odswiez
            // 
            this.Odswiez.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Odswiez.Location = new System.Drawing.Point(126, 319);
            this.Odswiez.Name = "Odswiez";
            this.Odswiez.Size = new System.Drawing.Size(116, 36);
            this.Odswiez.TabIndex = 7;
            this.Odswiez.Text = "Odśwież";
            this.Odswiez.UseVisualStyleBackColor = true;
            // 
            // Dodaj_wizyte
            // 
            this.Dodaj_wizyte.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Dodaj_wizyte.Location = new System.Drawing.Point(438, 319);
            this.Dodaj_wizyte.Name = "Dodaj_wizyte";
            this.Dodaj_wizyte.Size = new System.Drawing.Size(164, 37);
            this.Dodaj_wizyte.TabIndex = 8;
            this.Dodaj_wizyte.Text = "Dodaj wizytę";
            this.Dodaj_wizyte.UseVisualStyleBackColor = true;
            this.Dodaj_wizyte.Click += new System.EventHandler(this.Dodaj_wizyte_Click);
            // 
            // Lekarz
            // 
            this.Lekarz.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Lekarz.Location = new System.Drawing.Point(438, 44);
            this.Lekarz.Name = "Lekarz";
            this.Lekarz.Size = new System.Drawing.Size(164, 26);
            this.Lekarz.TabIndex = 9;
            this.Lekarz.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.Lekarz_MaskInputRejected);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(285, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 19);
            this.label4.TabIndex = 10;
            this.label4.Text = "Wizyta";
            // 
            // data
            // 
            this.data.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.data.Location = new System.Drawing.Point(289, 44);
            this.data.Name = "data";
            this.data.Size = new System.Drawing.Size(116, 26);
            this.data.TabIndex = 11;
            this.data.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(340, 373);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 41);
            this.button1.TabIndex = 12;
            this.button1.Text = "Dodaj pacjenta";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rejestracja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.data);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Lekarz);
            this.Controls.Add(this.Dodaj_wizyte);
            this.Controls.Add(this.Odswiez);
            this.Controls.Add(this.Usun_wizyte);
            this.Controls.Add(this.PESEL);
            this.Controls.Add(this.Lista_lekarzy);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "rejestracja";
            this.Size = new System.Drawing.Size(633, 440);
            this.Load += new System.EventHandler(this.rejestracja_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox Lista_lekarzy;
        private System.Windows.Forms.ListBox PESEL;
        private System.Windows.Forms.Button Usun_wizyte;
        private System.Windows.Forms.Button Odswiez;
        private System.Windows.Forms.Button Dodaj_wizyte;
        private System.Windows.Forms.MaskedTextBox Lekarz;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker data;
        private System.Windows.Forms.Button button1;
    }
}
