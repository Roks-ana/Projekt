﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    class PatientsRepository
    {
        private static string SELECT_PACJENT = "SELECT imie, nazwisko FROM `pacjenci`";

        public static List<Patient> GetAllPatients()
        {
            List<Patient> patients = new List<Patient>();
            using (var conn = DBConnection.Instance.Connection)
            {
                conn.Open();
                using (MySqlCommand command = new MySqlCommand(SELECT_PACJENT, conn))
                {
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        patients.Add(new Patient(reader));
                    }

                }



            }


            return patients;
        }
    }
}
