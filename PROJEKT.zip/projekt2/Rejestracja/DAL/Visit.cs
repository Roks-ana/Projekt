﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace Rejestracja.DAL
{
    public class Visit
    {
         public byte ID{ get; set; }

        public string Pesel { get; set; }
        public  string Data { get; set; }
        public string Godzina { get; set; }


        public override string ToString()
        {
            return $" {Godzina}";
        }

        public Visit(MySqlDataReader reader)
        {
           
            //Pesel = (string)reader["pesel"];
            
            Godzina = (string)reader["godzina"];
        }
    }
}
