﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    class VisitRepository
    {

        private static string SELECT_W = " SELECT godzina  FROM `wizyta`";

        public static List<Visit> GetAllVisit()
        {
            List<Visit> wizyty = new List<Visit>();
            using (var conn = DBConnection.Instance.Connection)
            {
                conn.Open();
                using (MySqlCommand command = new MySqlCommand(SELECT_W, conn))
                {
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        wizyty.Add(new Visit(reader));
                    }

                }



            }


            return wizyty;
        }
    }
}