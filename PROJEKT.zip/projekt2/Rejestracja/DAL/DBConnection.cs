﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    class DBConnection
    {
        private static DBConnection instance = null;

        public static DBConnection Instance
        {
            get
            {
                return instance ?? (instance = new DBConnection());
            }
        }
        private DBConnection()
        {
            MySqlConnectionStringBuilder connString = new MySqlConnectionStringBuilder();
            connString.Port = uint.Parse(DBInfo.Port);
            connString.Database = DBInfo.Database;
            connString.UserID = DBInfo.User;
            connString.Password = DBInfo.Password;
            connString.Server = DBInfo.Server;
            Connection = new MySqlConnection(connString.ToString());
            Console.WriteLine(connString);
        }

        public MySqlConnection Connection { get; private set; }
    }
}
