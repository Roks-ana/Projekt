﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using Rejestracja.DAL;

namespace Rejestracja
{
    using DAL;
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void rejestracja1_Load(object sender, EventArgs e)
        {
            var doc = DoctorsRepository.GetAllDoctors();
            var wiz = VisitRepository.GetAllVisit();
            var pes = PeselRepository.GetAllPesel();
            


            foreach (var d in doc)
                Console.WriteLine(d);
            rejestracja1.ListLekarzy = doc.ToArray();

            foreach (var w in wiz)
                Console.WriteLine(w);
            rejestracja1.ListWizyty = wiz.ToArray();

            foreach (var p in pes)
                Console.WriteLine(p);
            rejestracja1.ListPesele = pes.ToArray();
        }
        private void lista_pacjenci_Load(object sender, EventArgs e)
        {
            var pac = PatientsRepository.GetAllPatients();
            foreach (var pa in pac)
                Console.WriteLine(pa);
            DAL.Patient.ListPacjenci = pac.ToArray();
        }

        public DAL.Patient[] ListPacjenci
        {
            set
            {
                
                lista_pacjenci.Items.Clear();
                lista_pacjenci.Items.AddRange(value);
            }
        }



        private void lista_pacjenci_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }

}
