﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rejestracja.DAL
{
    public partial class Okno_pacjent : Form
    {
        public Okno_pacjent()
        {
            InitializeComponent();
        }

        private void imie_TextChanged(object sender, EventArgs e)
        {

        }
  
        private void button2_Click(object sender, EventArgs e)
        {
            

            Lista.Items.Add(new Patient(imie.Text, nazwisko.Text, pesel.Text, nr_tel.Text, Convert.ToDateTime(data.Text)));
            //imie.Clear();
            //nazwisko.Clear();
            //data.ResetText();

            //if (imie.Text == "" || nazwisko.Text == "")
            //{
            //    if (imie.Text == "")
            //        errorProvider1.SetError(imie, "Puste Pole");
            //    if (nazwisko.Text == "")
            //        errorProvider1.SetError(nazwisko, "Puste Pole");
            //    MessageBox.Show("Brak danych!");
            //}



            //else
            //{


            //errorProvider1.SetError(imie, "");
            //errorProvider1.SetError(nazwisko, "");

                imie.Clear();
                nazwisko.Clear();
                data.ResetText();
            
            }

        

        }
    }

