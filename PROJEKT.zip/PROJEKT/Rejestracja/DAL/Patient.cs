﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    public class Patient
    {
        public Patient(string firstname, string lastname, string pesel, string nr_tel, DateTime birthdaydate )
        {

            this.FirstNameP = firstname;
            this.LastNameP = lastname;
            this.ID = pesel;
            this.NrTel = nr_tel;
            this.BirthdayDate = birthdaydate;



        }

        public string FirstNameP { get; set; }
        public string LastNameP { get; set; }
        public string ID { get; set; }  
        public string NrTel { get; set; }

        public DateTime BirthdayDate;


        //public override string ToString()
        //{
        //    return $"{ID} {FirstNameP} {LastNameP}";
        //}

        //public Patient(MySqlDataReader reader)
        //{
        //    ID = (string)reader["pesel"];
        //    FirstNameP = (string)reader["imie"];
        //    LastNameP = (string)reader["nazwisko"];
        //}



    }
}

