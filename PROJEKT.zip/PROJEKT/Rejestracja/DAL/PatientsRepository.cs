﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    public class PatientsRepository
    {


        

        public void DodajPacjenta(Patient user)
        {

            String name = user.FirstNameP;
            String surname = user.LastNameP;
            String pesel = user.ID;
            String telephone = user.NrTel;
            DateTime data = user.BirthdayDate;


            using (var conn = DBConnection.Instance.Connection)
            {
                try
                {
                    conn.Open();
                    using (MySqlCommand command = new MySqlCommand($"INSERT INTO pacjenci VALUES( '{name}', '{surname}', '{pesel}', '{telephone}', '{data}')", conn))
                    {
                        command.ExecuteNonQuery();
                        user.FirstNameP = "";
                        user.LastNameP = "";
                        user.ID = "";
                        user.NrTel = "";
                    }
                    conn.Close();
                    MessageBox.Show("Dodano");
                }
                catch (Exception exc)
                {
                    Console.WriteLine("ERROR: " + exc.Message);
                }

            }



        }

        public void DodajPacjenta()
        {
           
        }
    }
}
