﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rejestracja
{
    public partial class Okno3_cs : Form
    {
        public Okno3_cs()
        {
            InitializeComponent();
        }

        private void Okno3_cs_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

   
    
    private void button2_Click(object sender, EventArgs e)
        {
            
            //if (imie.Text == "" || nazwisko.Text == "")
            //{
            //    if (imie.Text == "")
            //        errorProvider1.SetError(imie, "Puste Pole");
            //    if (nazwisko.Text == "")
            //        errorProvider1.SetError(nazwisko, "Puste Pole");
            //    MessageBox.Show("Brak danych!");
            //}



            //else
            //{


            //    errorProvider1.SetError(imie, "");
            //    errorProvider1.SetError(nazwisko, "");
            //    lista.Items=
            //    nazwisko.Clear();
            //    data.ResetText();
            //}


        }

        private void lista_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }

